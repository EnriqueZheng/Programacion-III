#ifndef POO2_UNIT6_ADAPTADORES_POO_V2021_2_P5_H
#define POO2_UNIT6_ADAPTADORES_POO_V2021_2_P5_H
#include "stack_utec.h"
#include <string>

inline bool is_equation_balanced(std::string source) {
    utec::stack<char> s;
    for (char ch : source) {
        if (ch == '(' || ch == '[' || ch == '{') {
            s.push(ch);
        } else if (ch == ')' || ch == ']' || ch == '}') {
            if (s.empty()) return false;
            char open = s.top();
            s.pop();
            if ((ch == ')' && open != '(') ||
                (ch == ']' && open != '[') ||
                (ch == '}' && open != '{')) {
                return false;
            }
        }
    }
    return s.empty();
}

#endif //POO2_UNIT6_ADAPTADORES_POO_V2021_2_P5_H
