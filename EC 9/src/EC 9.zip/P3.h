#ifndef POO2_UNIT6_ADAPTADORES_POO_V2021_2_P3_H
#define POO2_UNIT6_ADAPTADORES_POO_V2021_2_P3_H
#include "stack_utec.h"
#include <string>

inline std::string process_text_by_stack(std::string source) {
    utec::stack<char> s;
    std::string result;
    for (char ch : source) {
        if (ch == '*') {
            if (!s.empty()) {
                result += s.top();
                s.pop();
            }
        } else {
            s.push(ch);
        }
    }
    return result;
}

#endif //POO2_UNIT6_ADAPTADORES_POO_V2021_2_P3_H
