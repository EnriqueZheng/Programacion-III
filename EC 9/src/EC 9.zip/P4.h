#ifndef POO2_UNIT6_ADAPTADORES_POO_V2021_2_P4_H
#define POO2_UNIT6_ADAPTADORES_POO_V2021_2_P4_H
#include "queue_utec.h"
#include <string>

inline std::string process_text_by_queue(const std::string& source) {
    utec::queue<char> q;
    std::string result;
    for (char ch : source) {
        if (ch == '*') {
            if (!q.empty()) {
                result += q.front();
                q.pop();
            }
        } else {
            q.push(ch);
        }
    }
    return result;
}

#endif //POO2_UNIT6_ADAPTADORES_POO_V2021_2_P4_H
